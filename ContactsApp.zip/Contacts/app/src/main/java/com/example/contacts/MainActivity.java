package com.example.contacts;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.contacts.data.Contact;
import com.example.contacts.data.ContactData;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    // This code allow me to make connection between main activity and the database for my contact.
    ContactData contactData;

    // The list of unique ids from the Contacts table***
    List ids = new ArrayList<Long>();

    // The index of the current Contact's id in the ids list***
    Integer currentContactIndex = -1;

    // Declaring variables for edit text
    EditText edFirstName;
    EditText edSurname;
    EditText edPhoneNumber;
    EditText edHomeNumber;
    EditText edEmail;
    EditText edDOB;
    EditText edAddressLine1;
    EditText edAddressLine2;
    EditText edAddressLine3;
    EditText edAddressLine4;

    // Declaring variables for button
    Button BtnAdd;
    Button BtnPrevContact;
    Button BtnNextContact;
    Button BtnDelContact;

    @Override
    // This code will be running when the activity is first created on Android system.
    protected void onCreate(Bundle savedInstanceState) {
        // Setup coding
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // This code will create the database (if necessary) and connect to it
        contactData = new ContactData(this.getApplicationContext());

        // This code will try getting the list of ids from the Contact table
        // Also the list will be empty if there's is no user input
        ids = contactData.getContactIDs();

        // If user input data then contacts will be recorded then 'refer' to the first one
        if (ids.size() > 0) {
            // This will hold 0 index for the first Contacts
            currentContactIndex = 0;
        }

        // This code ensure that EditTexts load into memory to hold data
        edFirstName = findViewById(R.id.idFirstName);
        edSurname = findViewById(R.id.idSurname);
        edPhoneNumber = findViewById(R.id.idPhoneNumber);
        edHomeNumber = findViewById(R.id.idHomeNumber);
        edEmail = findViewById(R.id.idEmail);
        edDOB = findViewById(R.id.idDOB);
        edAddressLine1 = findViewById(R.id.idAddressLine1);
        edAddressLine2 = findViewById(R.id.idAddressLine2);
        edAddressLine3 = findViewById(R.id.idAddressLine3);
        edAddressLine4 = findViewById(R.id.idAddressLine4);


        // This code will allow load buttons and setup their event handlers
        loadButtonsAndSetHandlers();
    }

    private void loadButtonsAndSetHandlers() {
        //This code ensure that button load into memory
        BtnAdd = findViewById(R.id.idAddbtn);
        BtnDelContact = findViewById(R.id.BtnDel);
        BtnNextContact = findViewById(R.id.BtnNext);
        BtnPrevContact = findViewById(R.id.BtnPrev);


        // In this code it will set the event handlers to do it action when user click on these buttons.
        BtnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                handleBtnAdd();
            }
        });

        BtnDelContact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                handleBtnDelContact();
            }
        });

        BtnNextContact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                handleBtnNext();
            }
        });

        BtnPrevContact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                handleBtnPrev();
            }
        });
    }

    private void handleBtnPrev() {
        currentContactIndex = currentContactIndex - 1;
        showCurrentContact();
    }

    private void handleBtnNext() {
        currentContactIndex = currentContactIndex + 1;
        showCurrentContact();
    }


    //This is the code will run when the add button is press by user
    private void handleBtnAdd() {

        // This code will load data from text edit
        String firstName = edFirstName.getText().toString();
        String Surname = edSurname.getText().toString();
        String phoneNumber = edPhoneNumber.getText().toString();
        String homeNumber = edHomeNumber.getText().toString();
        String Email = edEmail.getText().toString();
        String DOB = edDOB.getText().toString();
        String AddressLine1 = edAddressLine1.getText().toString();
        String AddressLine2 = edAddressLine2.getText().toString();
        String AddressLine3 = edAddressLine3.getText().toString();
        String AddressLine4 = edAddressLine4.getText().toString();

        // This will add the Contact
        contactData.addContact(firstName, Surname, phoneNumber, homeNumber, Email, DOB, AddressLine1, AddressLine2, AddressLine3, AddressLine4);

        // It will generate the new set of ids
        ids = contactData.getContactIDs();
        currentContactIndex = 0;
        showCurrentContact();

        // This will update buttons statuses
        refreshButtonStatus();

        // When the add button is clicked then this message will show up to the user
        showLongToast("New Contact added");
    }

    private void handleBtnDelContact() {
        // This code will delete the current Contact
        Long ContactId = (Long) ids.get(currentContactIndex);
        contactData.deleteContact(ContactId);

        // get the new ids
        ids = contactData.getContactIDs();

        // If user has deleted the last one then set the currentContactIndex to -1
        if (ids.size() == 0) {
            currentContactIndex = -1;
        } else {
            // set it to the first Contact
            currentContactIndex = 0;
        }

        // update buttons statuses
        refreshButtonStatus();

        showCurrentContact();

        // When the add button is clicked then this message will show up to the user
        showLongToast("Contact deleted");
    }

    @Override
    // The system will run this method before the activity is shown
    // It is part of the Activity Life Cycle***
    protected void onResume() {
        // call the superclass onResume() method, thus linking our Activity***
        // properly with the system***
        super.onResume();

        showCurrentContact();

        // This will enable or disable buttons according to the data
        refreshButtonStatus();
    }

    private void showCurrentContact() {
        // It will load data if there are any Contact in the table and will show the current Contact
        if (currentContactIndex != -1) {
            // Get the current Contact's data
            Long currentContactId = (Long) ids.get(currentContactIndex);
            Contact theContactToDisplay = contactData.getContact(currentContactId);

            // Show the current Contact's data
            edFirstName.setText(theContactToDisplay.firstName);
            edSurname.setText(theContactToDisplay.surName);
            edPhoneNumber.setText(theContactToDisplay.phoneNumber);
            edHomeNumber.setText(theContactToDisplay.homeNumber);
            edEmail.setText(theContactToDisplay.email);
            edDOB.setText(theContactToDisplay.DOB);
            edAddressLine1.setText(theContactToDisplay.addressLine1);
            edAddressLine2.setText(theContactToDisplay.addressLine2);
            edAddressLine3.setText(theContactToDisplay.addressLine3);
            edAddressLine4.setText(theContactToDisplay.addressLine4);

        } else {
            // display no data
            edFirstName.setText("");
            edSurname.setText("");
            edPhoneNumber.setText("");
            edHomeNumber.setText("");
            edEmail.setText("");
            edDOB.setText("");
            edAddressLine1.setText("");
            edAddressLine2.setText("");
            edAddressLine3.setText("");
            edAddressLine4.setText("");

        }
        // This will refresh the enabled//disabled status of the buttons
        refreshButtonStatus();
    }

    private void refreshButtonStatus() {
        BtnDelContact.setEnabled(true);
        // 0 or 1 Contact in the database
        if (ids.size() == 0 || ids.size() == 1) {
            // It will disable all (except the Add button because user can always add a Contact)
            BtnNextContact.setEnabled(false);
            BtnPrevContact.setEnabled(false);


            if (ids.size() == 0) {
                // if it does not hold any data then it won't delete as there isn't any contact data.
                BtnDelContact.setEnabled(false);
            }
        } else {
            // if the contact display first
            if (currentContactIndex == 0) {
                BtnPrevContact.setEnabled(false);
                BtnNextContact.setEnabled(true);

            } else {
                // if the contact display last
                if (currentContactIndex == ids.size() - 1) {
                    BtnPrevContact.setEnabled(true);
                    BtnNextContact.setEnabled(false);

                } else {
                    // if the contact display somewhere in the middle
                    BtnPrevContact.setEnabled(true);
                    BtnNextContact.setEnabled(true);

                }
            }
        }
    }

    private void showLongToast(String message) {
        Context context = getApplicationContext();
        CharSequence text = message;
        int duration = Toast.LENGTH_LONG;

        Toast toast = Toast.makeText(context, text, duration);
        toast.show();
    }

    public void hideKeyboard(View view) {
        Context context = getApplicationContext();
        InputMethodManager inputMethodManager =
                (InputMethodManager) context.getSystemService(Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }
}