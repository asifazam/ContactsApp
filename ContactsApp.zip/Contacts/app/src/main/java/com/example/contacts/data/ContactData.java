package com.example.contacts.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class ContactData {

    private static final String TAG = ContactData.class.getSimpleName();
    private final DBHelper dbHelper;

    public ContactData(Context context) {
        dbHelper = new DBHelper(context);
        Log.i(TAG, "Initialised Contact data");
    }

    public void addContact(String Firstname, String Surname, String phoneNumber, String homeNumber, String Email, String DOB, String addressLine1, String addressLine2, String addressLine3, String addressLine4) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(ContactDataStruct.ContactDataTable.COL_FirstName, Firstname);
        values.put(ContactDataStruct.ContactDataTable.COL_Surname, Surname);
        values.put(ContactDataStruct.ContactDataTable.COL_Phone_Number, phoneNumber);
        values.put(ContactDataStruct.ContactDataTable.COL_Home_Number, homeNumber);
        values.put(ContactDataStruct.ContactDataTable.COL_Email, Email);
        values.put(ContactDataStruct.ContactDataTable.COL_DOB, DOB);
        values.put(ContactDataStruct.ContactDataTable.COL_AddressLine1, addressLine1);
        values.put(ContactDataStruct.ContactDataTable.COL_AddressLine2, addressLine2);
        values.put(ContactDataStruct.ContactDataTable.COL_AddressLine3, addressLine3);
        values.put(ContactDataStruct.ContactDataTable.COL_AddressLine4, addressLine4);

        /* --- insert to db --- */
        db.insert(ContactDataStruct.ContactDataTable.TABLE_NAME, null, values);
        db.close();
    }


    public int deleteContact(Long contactId) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        // Define 'where' part of query.
        String selection = ContactDataStruct.ContactDataTable._ID + " = ?";
        // Specify arguments in placeholder order.
        // convert integer to string
        String gid = contactId.toString();
        String[] selectionArgs = {gid};
        // Issue SQL statement.
        int deletedRows = db.delete(ContactDataStruct.ContactDataTable.TABLE_NAME, selection, selectionArgs);
        db.close();
        return deletedRows;
    }

    public int updateContact(int ContactId, String Firstname, String Surname, String phoneNumber, String homeNumber, String Email, String DOB, String addressLine1, String addressLine2, String addressLine3, String addressLine4) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        // New values for one column
        ContentValues values = new ContentValues();
        values.put(ContactDataStruct.ContactDataTable.COL_FirstName, Firstname);
        values.put(ContactDataStruct.ContactDataTable.COL_Surname, Surname);
        values.put(ContactDataStruct.ContactDataTable.COL_Phone_Number, phoneNumber);
        values.put(ContactDataStruct.ContactDataTable.COL_Home_Number, homeNumber);
        values.put(ContactDataStruct.ContactDataTable.COL_Email, Email);
        values.put(ContactDataStruct.ContactDataTable.COL_DOB, DOB);
        values.put(ContactDataStruct.ContactDataTable.COL_AddressLine1, addressLine1);
        values.put(ContactDataStruct.ContactDataTable.COL_AddressLine2, addressLine2);
        values.put(ContactDataStruct.ContactDataTable.COL_AddressLine3, addressLine3);
        values.put(ContactDataStruct.ContactDataTable.COL_AddressLine4, addressLine4);

        // Which row to update, based on the title
        String selection = ContactDataStruct.ContactDataTable._ID + " = ?";
        String gid = new Integer(ContactId).toString();
        String[] selectionArgs = {gid};

        int count = db.update(
                ContactDataStruct.ContactDataTable.TABLE_NAME,
                values,
                selection,
                selectionArgs);

        db.close();
        return count;
    }

    public List getContactIDs() {
        List itemIds = new ArrayList<Long>();

        SQLiteDatabase db = dbHelper.getReadableDatabase();

        // Define a projection that specifies which columns from the database
        // User will actually use after this query. We only want the IDs, in this case
        String[] projection = {
                ContactDataStruct.ContactDataTable._ID
        };

        // How user want the results sorted in the resulting Cursor
        String sortOrder =
                ContactDataStruct.ContactDataTable.COL_FirstName + ", " + ContactDataStruct.ContactDataTable.COL_Surname + " asc";

        Cursor cursor = db.query(
                ContactDataStruct.ContactDataTable.TABLE_NAME,   // The table to query
                projection,             // The array of columns to return (pass null to get all)
                null,              // The columns for the WHERE clause
                null,          // The values for the WHERE clause
                null,                   // don't group the rows
                null,                   // don't filter by row groups
                sortOrder               // The sort order
        );

        while (cursor.moveToNext()) {
            Long itemId = cursor.getLong(
                    cursor.getColumnIndexOrThrow(ContactDataStruct.ContactDataTable._ID));
            itemIds.add(itemId);
        }
        cursor.close();
        db.close();

        return itemIds;
    }

    public Contact getContact(Long ContactId) {
        Contact result = null; // set it to no Contact

        SQLiteDatabase db = dbHelper.getReadableDatabase();

        // This code define a projection that specifies which columns from the database
        // user will actually use after this query.
        String[] projection = {
                ContactDataStruct.ContactDataTable.COL_FirstName,
                ContactDataStruct.ContactDataTable.COL_Surname,
                ContactDataStruct.ContactDataTable.COL_Phone_Number,
                ContactDataStruct.ContactDataTable.COL_Home_Number,
                ContactDataStruct.ContactDataTable.COL_Email,
                ContactDataStruct.ContactDataTable.COL_DOB,
                ContactDataStruct.ContactDataTable.COL_AddressLine1,
                ContactDataStruct.ContactDataTable.COL_AddressLine2,
                ContactDataStruct.ContactDataTable.COL_AddressLine3,
                ContactDataStruct.ContactDataTable.COL_AddressLine4,
        };

        // Filter results WHERE "title" = 'My Title'
        String selection = ContactDataStruct.ContactDataTable._ID + " = ?";
        String[] selectionArgs = {ContactId.toString()};

        // How user want the results sorted in the resulting Cursor
        String sortOrder =
                ContactDataStruct.ContactDataTable.COL_FirstName + ", " + ContactDataStruct.ContactDataTable.COL_Surname + " DESC";

        Cursor cursor = db.query(
                ContactDataStruct.ContactDataTable.TABLE_NAME,   // The table to query
                projection,             // The array of columns to return (pass null to get all)
                selection,              // The columns for the WHERE clause
                selectionArgs,          // The values for the WHERE clause
                null,           // don't group the rows
                null,            // don't filter by row groups
                sortOrder               // The sort order
        );

        if (cursor.moveToFirst()) {
            Contact g = new Contact();
            g.firstName = cursor.getString(cursor.getColumnIndexOrThrow(ContactDataStruct.ContactDataTable.COL_FirstName));
            g.surName = cursor.getString(cursor.getColumnIndexOrThrow(ContactDataStruct.ContactDataTable.COL_Surname));
            g.phoneNumber = cursor.getString(cursor.getColumnIndexOrThrow(ContactDataStruct.ContactDataTable.COL_Phone_Number));
            g.homeNumber = cursor.getString(cursor.getColumnIndexOrThrow(ContactDataStruct.ContactDataTable.COL_Home_Number));
            g.email = cursor.getString(cursor.getColumnIndexOrThrow(ContactDataStruct.ContactDataTable.COL_Email));
            g.DOB = cursor.getString(cursor.getColumnIndexOrThrow(ContactDataStruct.ContactDataTable.COL_DOB));
            g.addressLine1 = cursor.getString(cursor.getColumnIndexOrThrow(ContactDataStruct.ContactDataTable.COL_AddressLine1));
            g.addressLine2 = cursor.getString(cursor.getColumnIndexOrThrow(ContactDataStruct.ContactDataTable.COL_AddressLine2));
            g.addressLine3 = cursor.getString(cursor.getColumnIndexOrThrow(ContactDataStruct.ContactDataTable.COL_AddressLine3));
            g.addressLine4 = cursor.getString(cursor.getColumnIndexOrThrow(ContactDataStruct.ContactDataTable.COL_AddressLine4));
            cursor.close();
            db.close();
            return g;
        } else {
            cursor.close();
            db.close();
            return null;
        }
    }

    private void clearAllContactData() {
        // empty table
        String sqlDel = "delete from " + ContactDataStruct.ContactDataTable.TABLE_NAME;

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.execSQL(sqlDel);
        db.close();
    }

    /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    // DATABASE_NAME RELATED DEFINITIONS
    /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public final class ContactDataStruct {
        // General DB related information
        static final int DB_VERSION = 1;
        static final String DATABASE_NAME = "ContactData.db";
        private ContactDataStruct() {
        }

        /* Inner class that defines the table contents */
        public abstract class ContactDataTable implements BaseColumns {
            public static final String TABLE_NAME = "ContactData";
            public static final String _ID = "_id";
            public static final String COL_FirstName = "FirstName";
            public static final String COL_Surname = "Surname";
            public static final String COL_Phone_Number = "PhoneNumber";
            public static final String COL_Home_Number = "HomeNumber";
            public static final String COL_Email = "Email";
            public static final String COL_DOB = "DateofBirth";
            public static final String COL_AddressLine1 = "AddressLine1";
            public static final String COL_AddressLine2 = "AddressLine2";
            public static final String COL_AddressLine3 = "AddressLine3";
            public static final String COL_AddressLine4 = "AddressLine4";
        }
    }

    /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public final class DBHelper extends SQLiteOpenHelper {
        /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

        public DBHelper(Context context) {
            super(context, ContactDataStruct.DATABASE_NAME, null, ContactDataStruct.DB_VERSION);
        }

        /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
        @Override
        public void onCreate(SQLiteDatabase db) {
            // This generate the create table SQL statement
            String sqlCreate = "create table " + ContactDataStruct.ContactDataTable.TABLE_NAME + " ("
                    + ContactDataStruct.ContactDataTable._ID + " INTEGER primary key, "
                    + ContactDataStruct.ContactDataTable.COL_FirstName + " VARCHAR(255), "
                    + ContactDataStruct.ContactDataTable.COL_Surname + " VARCHAR(255), "
                    + ContactDataStruct.ContactDataTable.COL_Phone_Number + " VARCHAR(255), "
                    + ContactDataStruct.ContactDataTable.COL_Home_Number + " VARCHAR(255), "
                    + ContactDataStruct.ContactDataTable.COL_Email + " VARCHAR(255), "
                    + ContactDataStruct.ContactDataTable.COL_DOB + " VARCHAR(255), "
                    + ContactDataStruct.ContactDataTable.COL_AddressLine1 + " VARCHAR(255), "
                    + ContactDataStruct.ContactDataTable.COL_AddressLine2 + " VARCHAR(255), "
                    + ContactDataStruct.ContactDataTable.COL_AddressLine3 + " VARCHAR(255), "
                    + ContactDataStruct.ContactDataTable.COL_AddressLine4 + " VARCHAR(255)) ";


            // This code execute the create table statement
            db.execSQL(sqlCreate);
        }

        /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("drop table " + ContactDataStruct.ContactDataTable.TABLE_NAME);
            this.onCreate(db);
        }
    }
}
