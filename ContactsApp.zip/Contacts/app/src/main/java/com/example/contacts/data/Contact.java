package com.example.contacts.data;
// In this code I'm naming my variables as String, which will hold my Contact input data.
public class Contact {
    public String firstName;
    public String surName;
    public String phoneNumber;
    public String homeNumber;
    public String email;
    public String DOB;
    public String addressLine1;
    public String addressLine2;
    public String addressLine3;
    public String addressLine4;
}
